﻿namespace SoftJail.DataProcessor.ExportDto
{
    using System.Text.Json.Serialization;

    public class OfficerOutputModel
    {
        public string OfficerName { get; set; }

        public string Department { get; set; }
    }
}