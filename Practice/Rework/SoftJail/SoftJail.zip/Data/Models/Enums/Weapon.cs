﻿namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper
    }
}