﻿namespace BookShop
{
    public static class ConstantInputs
    {
        public const int copies = 5000;
        public const string goldenBook = "gold";
        public const decimal lookedForPrice = 40;
    }
}
