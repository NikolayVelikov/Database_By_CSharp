﻿namespace BookShop
{
    public static class ConstantInputs
    {
        public const int copies = 5000;
    }
}
