﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=DESKTOP-8F63LT6\\TEW_SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
