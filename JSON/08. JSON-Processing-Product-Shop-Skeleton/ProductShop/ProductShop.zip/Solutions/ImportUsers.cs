﻿namespace ProductShop.Solutions
{
    using Newtonsoft.Json;

    using ProductShop.Data;
    using ProductShop.Models;

    public class ImportUsers
    {
        public static string Solution(ProductShopContext context, string inputJson)
        {
            var objUser = JsonConvert.DeserializeObject<User[]>(inputJson);
            context.AddRange(objUser);

            context.SaveChanges();

           return $"Successfully imported {objUser.Length}";
        }
    }
}
