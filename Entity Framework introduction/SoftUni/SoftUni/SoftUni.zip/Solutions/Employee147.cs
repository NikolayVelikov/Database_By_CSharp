﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using System.Linq;
using System.Text;

namespace SoftUni.Solutions
{
    public class Employee147
    {
        public static string Solution(SoftUniContext context)
        {
            var agent147 = context.Employees.Select(x => new
            {
                x.EmployeeId,
                x.FirstName,
                x.LastName,
                x.JobTitle,
                Projects = x.EmployeesProjects.Select(y => new
                {
                    y.Project.Name
                })
            }).Where(x=> x.EmployeeId == 147);

            StringBuilder sb = new StringBuilder();
            foreach (var agent in agent147)
            {
                string firstName = agent.FirstName;
                string lastName = agent.LastName;
                string jobTitle = agent.JobTitle;

                sb.AppendLine($"{firstName} {lastName} - {jobTitle}");

                var projects = agent.Projects.OrderBy(x => x.Name);
                foreach (var project in projects)
                {
                    string projectName = project.Name;
                    sb.AppendLine(projectName);
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}
