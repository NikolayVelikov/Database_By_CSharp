﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni.Solutions
{
    public class FindLatest10Projects
    {
        public static string Solution(SoftUniContext context)
        {
            var projects = context.Projects.OrderByDescending(x => x.StartDate).Take(10).OrderBy(x => x.Name).ToArray();

            StringBuilder sb = new StringBuilder();
            foreach (var project in projects)
            {
                sb.AppendLine(project.Name);
                sb.AppendLine(project.Description);
                sb.AppendLine(project.StartDate.ToString("M/d/yyyy h:mm:ss tt"));
            }
            
            //var projects = context.Projects.Select(x => new
            //{
            //    x.ProjectId,
            //    x.Name,
            //    x.Description,
            //    x.StartDate,
            //    x.EndDate
            //}).OrderBy(x => x.ProjectId).ToArray();

            //var last10Projects = projects.TakeLast(10).OrderByDescending(x => x.Name.Length).ThenBy(x => x.Name).ToArray();
            //StringBuilder sb = new StringBuilder();
            //foreach (var project in last10Projects)
            //{
            //    string name = project.Name;
            //    sb.AppendLine(name);
            //    string description = project.Description;
            //    sb.AppendLine(description);
            //    DateTime startDate = project.StartDate;
            //    sb.AppendLine(startDate.ToString("M/d/yyyy h:mm:ss tt"));
            //}

            return sb.ToString().TrimEnd();
        }
    }
}
