﻿namespace P01_StudentSystem
{
    public static class Conncetions
    {
        public const string dbConnect = @"Server=DESKTOP-8F63LT6\TEW_SQLEXPRESS;Database=StudentSystem;Integrated Security=true";
    }
}
