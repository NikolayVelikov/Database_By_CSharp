﻿namespace P03_FootballBetting
{
    public static class Connections
    {
        public const string dbConnect = @"Server=DESKTOP-8F63LT6\TEW_SQLEXPRESS;Database=FoodBall;Integrated Security=true";
    }
}
