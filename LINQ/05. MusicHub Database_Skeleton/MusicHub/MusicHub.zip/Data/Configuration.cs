﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-8F63LT6\TEW_SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
